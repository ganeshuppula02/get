# Undoable

![Undoable dashboard](docs/dashboard.png)

**Undo button for AI agents.** A safety layer that sits between AI agents (Claude Code, Gemini CLI, Codex CLI, Cursor, custom bots) and your real systems. It backs up risky actions before they happen and lets you undo mistakes.

**Undo what rewind can't.** Coding agents keep checkpoints of the files they edit, but not of what shell commands, database queries or API calls change. That's where the costly mistakes happen, and that's what Undoable covers.

## Quick start

One line installs it. You need Node.js 20 or newer (on Windows the installer offers to install it) and Git.

Windows (PowerShell):

```powershell
irm https://raw.githubusercontent.com/ganeshuppula02/get/main/install.ps1 | iex
```

Mac and Linux:

```bash
curl -fsSL https://raw.githubusercontent.com/ganeshuppula02/get/main/install.sh | sh
```

See it work first, on a sample project: `undoable demo` (one minute, no agent needed). Or from a file you were sent: `npm install -g ./undoable-cli-<version>.tgz`. Then, in the project your agent works on:

```bash
cd your-project
undoable setup         # a few plain questions, then everything is set up and checked
```

Prefer doing it by hand? `undoable init --global` protects every Claude Code session on this computer, `undoable init` sets up one project (`--cursor` for Cursor too), and `undoable doctor` checks everything.

Then start Claude Code in that folder as usual. That's it.

- Every shell command and file edit is checked before it runs: safe ones run, risky ones are backed up first, permanent ones wait for you.
- Backups are encrypted and kept outside the project, in `~/.undoable`.
- Undo anything with `undoable timeline` and `undoable undo s3`, or press Undo in `undoable dashboard`.
- Undo a whole agent session in one go: `undoable undo --session last`, or **Undo this session** in the dashboard. A restore point is kept first, so you can bring it all back if you change your mind.

**Database protection (optional):** set `UNDOABLE_DATABASE_URL` before starting your agent, and it gets a safe `query_database` tool. For Supabase, use the **Session pooler** address.

**Testing on Windows?** Follow the step-by-step guide: [docs/TESTING-WINDOWS.md](docs/TESTING-WINDOWS.md)

## Commands

| Command | What it does |
|---|---|
| `undoable init` | Connect Undoable to Claude Code in this folder (`--cursor` for Cursor too) |
| `undoable init --global` | Protect every Claude Code session on this computer, in any folder. Projects with their own setup keep it |
| `undoable remove` / `remove --global` | Take Undoable out again (backups are kept) |
| `undoable doctor` | Check the setup, and test that the hook really stops a dangerous command |
| `undoable dashboard` | Open the web dashboard. It runs only on your computer and is protected by a secret link |
| `undoable timeline` | Everything agents did here (`s` = shell, `d` = database) |
| `undoable undo s3` / `undoable undo d12` | Undo an action |
| `undoable diff s3` / `undoable diff --session last` | **See what an undo would change before you run it**: deleted files that come back, files the agent created that go away, the exact lines it changed, git branches, and database rows. Also a **Preview** button in the dashboard |
| `undoable sessions` | Each agent session here: when it ran, how many actions, how many can be undone |
| `undoable undo --session last` | Undo **everything** the agent did in a session (files, git, and database changes made during it), newest first. Or give a session id from `undoable sessions` |
| `undoable undo --since 15:15` | Undo everything since a time (also `30m`, `2h`, `3:15pm`) |
| `undoable approve d12` | Run a blocked database action you approve |
| `undoable check "<command>"` | See how a command would be treated (including your own rules) |
| `undoable rules` | Show and check this project's own rules (creates `.undoable/rules` with examples if there isn't one) |
| `undoable audit` / `undoable audit --csv` | What agents changed, **why** (in the agent's own words), and who approved it. `--csv` opens in Excel or Google Sheets |
| `undoable lock` / `undoable unlock` | Lock your `block` folders at the operating-system level too, so even scripts get "Access denied" / take the locks off |
| `undoable lock --admin` | An admin lock: only an administrator can unlock it (Windows asks with its "Allow this app?" prompt; macOS/Linux need sudo) |
| `undoable --version` | Show the version |

Settings are environment variables: see [docs/CONFIG.md](docs/CONFIG.md).

## Your own rules

Undoable's built-in checks protect every project. On top of them, each project can have its own rules in `.undoable/rules`. Commit the file so the whole team shares it. `undoable init` creates it with examples, all switched off.

```
block payments/                 # agents can never change anything in payments/ (reading is fine)
ask   .env                      # ask before changing any .env file, in any folder
ask   command: deploy*          # ask before any deploy command
block table: users              # no database changes to the users table
ask   table: orders by ravi     # changes to orders need Ravi's approval
ask   config/prod/** by senior  # any senior can approve production config changes
approver ravi 123456789         # Ravi's Telegram chat id (he gets it from: undoable telegram-setup)
approver priya 987654321
role senior ravi priya          # a role: "by senior" means Ravi or Priya
```

- **block** never runs, and no one can approve it from the agent's side. To allow it, a person changes the file.
- **ask** waits for a person, like Undoable's own 🔴 actions.
- **ask … by ravi** waits for Ravi only. Ravi gets a Telegram message with Approve / Block. Approvals from the dashboard, the terminal or anyone else's Telegram don't count. For shell commands and file edits, the agent is told it's waiting for Ravi; once Ravi approves, the agent can run that exact command once, within 30 minutes.
- **Roles:** `role senior ravi priya`, then `ask … by senior`. Any senior can approve, and nobody else can.
- **Audit trail:** every action is kept with the agent's own reason for it (Claude Code's one-line description of each command, and a `why` the agent gives for database changes), which session did it, and who approved it. Approvers see the reason on their phone before they decide. `undoable audit` shows it all; `--csv` gives a spreadsheet.
- An agent can't change the rules: anything that touches `.undoable/` waits for you.
- A mistake in the file never quietly switches a rule off: until it's fixed, anything beyond reading asks first. `undoable rules` and `undoable doctor` point at the line.
- Rules cover the folder **and everything in it**. Deleting a folder that *contains* something protected (`rm -rf config` when `config/.env` is protected) counts too, and so do tables reached through `ON DELETE CASCADE`.

### Two layers: the hook and the lock

1. **The hook (before every action).** Claude Code sends each shell command and file edit to Undoable before it runs. Undoable runs it, backs it up first, asks a person, or blocks it. It explains *why* to the agent, so the agent stops and tells you instead of trying again.
2. **The lock (the operating system).** `undoable lock` makes your `block` folders locked by Windows (`icacls`), macOS (`chflags`) or Linux (`chmod`). A script that deletes them from inside its own code gets "Access denied", even though the hook never saw what it does. Reading still works. `undoable unlock` takes the locks off; only you should run it (the agent is asked first, and commands that change a protected folder's permissions are blocked).

A normal lock belongs to your own account, so a program running as you could, on purpose, change the permissions back. For a lock that needs a person's approval to lift, use an **admin lock**: run `undoable lock --admin` from an administrator terminal (Windows: right-click PowerShell → Run as administrator; macOS/Linux: `sudo`). Administrators (root) then own the folder, so neither the agent, a script, nor a normal terminal can change it, and taking it off again (`undoable unlock`) needs an administrator too. On Windows that means the "Do you want to allow this app…" prompt a person has to click. Reading still works.

An agent that already runs *as administrator* (or root) can lift any lock, so don't give agents admin rights. For the hardest wall, run the agent as a different user or in a container that can't see those folders.

## A safe database login for agents

Agents usually connect with the same login as the app's owner, which can drop any table. One command makes a login that can't:

```bash
export UNDOABLE_DATABASE_URL=postgres://owner:…@host/db   # the owner's (admin) connection string
undoable db-role                                            # prints the agent's connection string, once
```

The new login (`undoable_agent`) can read, add, change and delete rows, and Undoable backs those changes up. It can't `DROP`, `TRUNCATE` or `ALTER` tables, or create new ones: Postgres only allows that to a table's owner, so those mistakes simply fail. Tables created later by the owner (migrations) get the same access automatically. It also can't delete Undoable's own records.

Give the agent the new connection string (as its `UNDOABLE_DATABASE_URL`), and keep the owner's out of the project's `.env` files, so the agent can't use that one instead.

- `--read-only`: it can only read. `--schema public,app`: which schemas (default `public`).
- Run it again any time to re-apply the rights; `--reset-password` for a new password; `--remove` to take the login away.
- `undoable doctor` warns when the agent's login could drop tables.

## Instant database rewind (Neon)

If your database is on [Neon](https://neon.com), Undoable can snapshot the **whole database** in seconds before any risky change, whatever its size, and put it all back with one command:

```bash
export UNDOABLE_NEON_API_KEY=...       # Neon console → Account settings → API keys
undoable rewind --check                # a real rewind on a test table: see that it works with your database
undoable rewind d12                    # the whole database back to just before action d12
undoable rewind c3                     # … or before a command that wiped it (dropdb, prisma migrate reset, …)
```

- Before a risky change from an agent (`DROP`, `TRUNCATE`, `DELETE`, `ALTER`, …), Undoable makes a Neon branch of the database (`undoable-snap-…`). The usual table backups are still made, so `undoable undo d12` still undoes just that one change.
- A table too big to back up no longer has to wait for a person: the snapshot covers it.
- Commands that wipe a whole Neon database get the instant snapshot as their safety copy, instead of a slow full dump.
- `rewind` asks before it runs and explains what it does: everything changed after that moment is rewound, by agents and by people. What was there just before is kept as a Neon branch (`undoable-before-rewind-…`), so a rewind can itself be undone. The connection string doesn't change.
- Neon plans limit how many branches a project has, so Undoable keeps the newest 5 snapshots (`UNDOABLE_NEON_KEEP`).
- `undoable doctor` shows whether instant rewind is on.

Other databases keep the table backups. Supabase and others may follow.

## Weekly report: what Undoable did for you

```bash
undoable report              # the last 7 days in this project
undoable report --days 30    # any period
undoable report --json       # the same numbers, for your own tools
```

It counts what agents did and what Undoable did about it: actions checked (and in how many sessions, including helper agents), what ran straight away, what was backed up first, what waited for a person, what your rules stopped, what was undone, approval requests, safety copies and database actions. Then it lists the most serious moments, with the agent's own reason, and ends with one sentence ready to share.

While `undoable alerts` or `undoable dashboard` runs, the same summary goes to Telegram and Slack once a week. The first one arrives a week after you start; a week with nothing checked sends nothing.

## Decision receipts: what the person saw

An audit trail usually says who approved. Undoable also keeps a **decision receipt** for every approve or block, sealed into the tamper-evident record (`undoable audit --verify`):

- **what the person was shown**, exactly: the command or SQL, the agent's reason, and its **impact** in plain words ("deletes 340 rows in public.orders", "drops public.orders (about 2,500 rows)");
- **where and when** they first saw it (terminal, dashboard, Slack or Telegram), and **how long** they took to decide;
- **whether they looked at the details** first (the dashboard's impact check, `undoable diff`), or decided straight from the notification;
- **who** decided, and **what happened next**, including when the database refused an approved change.

`undoable audit` shows it in one line, e.g. *approved by ravi on Slack after 42 s; saw: deletes 340 rows in public.orders; didn't open the details; then: ran as d12*. `undoable audit --csv` has it as a "decision record" column. Alerts on Telegram and Slack, the dashboard's Approve button and `undoable approve` now all show the impact before anyone decides.

## Phone alerts (Telegram)

1. In Telegram, open **@BotFather**, send `/newbot` and pick a name. You get a token like `123456:ABC-DEF…`
2. Run:
   ```bash
   export UNDOABLE_TELEGRAM_TOKEN=123456:ABC-DEF…
   undoable telegram-setup      # then send "hi" to your bot
   export UNDOABLE_TELEGRAM_CHAT_ID=<the number it prints>
   ```
3. Run `undoable alerts`, or `undoable dashboard`, which includes alerts.

Only your own Telegram chat can press Approve / Block; presses from anyone else are ignored. An action can only be approved once, even if you tap twice or also press Approve in the dashboard.

## Team approvals in Slack

Approval requests can go to a Slack channel, with **✅ Approve** and **🛑 Block** buttons, instead of (or as well as) Telegram. It uses Slack's Socket Mode, so nothing has to be hosted: it runs from `undoable alerts` or `undoable dashboard` on your computer. Needs Node.js 22 or newer.

1. Run `undoable slack-setup`. It prints a ready-made app definition to paste into Slack, and the steps to get two tokens and the channel id.
2. Set `UNDOABLE_SLACK_BOT_TOKEN`, `UNDOABLE_SLACK_APP_TOKEN` and `UNDOABLE_SLACK_CHANNEL`, then run `undoable slack-setup` again and press **Approve** on its test message. That tells Undoable your Slack member id (`UNDOABLE_SLACK_OWNER`).
3. Run `undoable alerts` or `undoable dashboard`.

Who can press the buttons: you (the owner) for ordinary approvals; for rules with `by ravi` or `by senior`, only those people, matched by the Slack member id in `.undoable/rules` (`approver ravi slack:U0123ABCD`). They're @-mentioned in the alert. Anyone else gets a private "not allowed" note and nothing happens.

## Codex CLI and Gemini CLI

`undoable init --codex --gemini` (in a project, or with `--global` for every folder) connects Undoable to OpenAI's Codex CLI and Google's Gemini CLI through their own hook systems. `undoable setup` asks about them too. Shell commands are checked first, and file edits (Codex patches, Gemini's `write_file` and `replace`) are backed up first, exactly as with Claude Code. Your rules apply too.

One difference: these agents can't ask you in the terminal from a hook. So when Undoable needs a person's OK, the action is **stopped and waits for you**: approve it with `undoable approve r3` in your own terminal, in `undoable dashboard`, or with the buttons on Telegram or Slack. Then ask the agent to run the same command again; it runs once. This also works when the agent runs in its "approve everything" mode.

- Codex: the hook goes into `.codex/hooks.json` (or `~/.codex/hooks.json` with `--global`). Open Codex and run `/hooks` once to trust it.
- Gemini: the hook goes into `.gemini/settings.json` (or `~/.gemini/settings.json`), next to your other settings.

## Cursor (experimental)

`undoable init --cursor` sets up Cursor's hooks too. See [docs/CURSOR.md](docs/CURSOR.md) for what's covered and what isn't. It's built from Cursor's published hook format but hasn't been tested inside Cursor yet.

## Other MCP agents

Any agent that supports MCP can use the safe database tool. `undoable init` writes `.mcp.json`; for other agents, add the same entry to their MCP settings.

## For developers

```bash
git clone https://github.com/undoable-dev/undoable-.git && cd undoable-
npm install
npm run release        # builds release/undoable-cli-<version>.tgz: one file testers install without access to this repo
npm run compile        # dist/ is committed so installs from GitHub need no build step: recompile before committing.
                       # (Deliberately not called "build": npm would rebuild the package during every Git install.)
npm run demo           # see how 22 example commands are labelled
npm run demo:undo      # watch Undo save a fake shop database from an agent's mistakes
npm run demo:dashboard # the dashboard filled with example agent activity
npm test               # all disaster tests (starts a local test Postgres)
```

## What Undoable covers

| What the agent does | Undoable's answer |
|---|---|
| Reads: listing files, `git status`, `SELECT`, `kubectl get`, `aws s3 ls` | 🟢 Runs straight away |
| Edits files (Claude Code's Write/Edit tools, `sed -i`, `>` redirects, `mv`, `cp`) inside the project | 🟡 File backed up first |
| Deletes inside the project, git resets, force pushes, branch deletes | 🟡 Backed up first |
| Database changes through `query_database` (insert, update, delete, also hidden in `WITH`) | 🟡 Tables backed up first, including tables changed through `ON DELETE CASCADE` links |
| Deletes outside the project, `.git`, everything (`.`, `~`, `C:\`), paths from variables, `find -delete`, `xargs rm` | 🔴 Waits for you |
| Scripts and npm scripts that contain delete code | 🔴 Waits for you |
| Database wipes: `DROP`/`TRUNCATE` on production, `CASCADE`, `prisma migrate reset`, `migrate:fresh`, `db:drop`, `manage.py flush`, `mysql`/`mongosh`/`redis-cli` deletes | 🔴 Waits for you |
| Cloud and hosting deletes: AWS, Azure, Google Cloud, Kubernetes, Helm, Terraform, Pulumi, Vercel, Fly, Heroku, Railway, Firebase, Supabase, GitHub (`gh repo delete`) | 🔴 Waits for you |
| API calls that delete, move money or send messages (`curl -X DELETE`, payment and email APIs) | 🔴 Waits for you |
| Commands on other machines (`ssh host …`, `rsync --delete`, `docker exec`) that change things | 🔴 Waits for you |
| System commands: shutdown, disk tools, stopping services | 🔴 Waits for you |

### Token guard

In April 2026 a coding agent found an API token with too much power and used it to delete a startup's production volume, and the backups on it, in one call. Undoable now watches for that:

- **Production credentials used to change things wait for a person:** `$RAILWAY_TOKEN`, `$env:PROD_DATABASE_URL`, `$STRIPE_SECRET_KEY` … in a POST/PUT/PATCH/DELETE request, or with a cloud or database tool. Reading with them is fine, and staging, dev, test and local credentials are left alone.
- **Raw secrets written into a command wait for a person:** API keys, tokens, passwords inside database addresses, private keys. That usually means the agent found a key somewhere and is using it.
- **Changes aimed at production wait for a person:** `--prod`, `--environment production`, `--context prod-…` (listing and reading are fine).
- **Secrets are never kept:** they're blanked out of the timeline, the audit log, approval requests, Slack and Telegram.
- **Your rules:** `block token: STRIPE_*` or `ask token: AWS_SECRET_ACCESS_KEY` in `.undoable/rules` covers any use of those credentials.

### Safety copies: backups that live somewhere else

In the same incident, the backups were stored on the volume that was deleted, so they went too. Now, before an agent's command deletes a **database or cloud storage**, Undoable first copies the data into the vault on your computer (encrypted, outside the cloud). The delete still waits for a person; if someone approves it by mistake, the data still exists.

- **Databases:** `DROP DATABASE/SCHEMA`, `dropdb`, Railway/Fly/Heroku/Neon/Supabase/AWS database and volume deletes, `prisma migrate reset`, `rails db:drop` … Undoable finds the database from the command, the environment variable it uses, `UNDOABLE_DATABASE_URL`/`DATABASE_URL`, or the project's `.env` files. With `pg_dump` installed it's a full copy; without it, Undoable copies every table's rows and column types itself.
- **Cloud storage:** `aws s3 rm/rb`, `gsutil rm`, `gcloud storage rm` (copied with the `aws` / `gcloud` tools, when installed and signed in).
- A big copy keeps going in the background, and the agent is asked to try again in a minute. If a copy fails, a person still decides, and is told.
- `undoable copies` lists them; `undoable restore-copy c1` puts one back (`--to postgres://…`, or `--to ./folder` to just unpack it). Only a person can restore.
- Passwords in database addresses are never written to disk. Copies follow the vault's size limit (`UNDOABLE_MAX_BACKUP_MB`) and keep-days.

### Helper agents (subagents)

Main agents start helper agents (Claude Code's subagents, Codex's sub-agents). Their commands and file edits go through the same checks, backups and rules, in the same session, so `undoable undo --session last` puts back the helpers' work too. Checked live with Claude Code: when a helper agent took "rm -rf build ." literally (deleting the whole project), Undoable stopped it, and the record shows which helper it was and its own reason.

- The timeline, `undoable audit` and the sealed record say which helper did what (`by: helper general-purpose (a8e68afe)`).
- `undoable sessions` lists each helper in a session; `undoable undo --agent <id>` (or `--agent last`) puts back only what that one helper did.

### A sealed audit record

Everything is also written to a **sealed audit record**: every command checked, file edit, backup, undo, approval, safety copy, lock, rule change and database action, in order. Each entry is sealed together with the one before it (HMAC-SHA256, with a key derived from your vault key), like links in a chain:

- `undoable audit --verify` checks every seal. Change, remove or reorder any entry and it says exactly where the record was altered, and fails for scripts.
- **Daily outside checkpoint:** with Slack or Telegram alerts running, the latest seal is posted once a day. Even someone who rewrote the whole record on your computer can't match a checkpoint that's already there: `undoable audit --verify --checkpoint <seal>` checks it. If the record ever stops verifying, you get an alert straight away.
- `undoable audit --export report.json` gives every entry, the verification result and how to check it, for compliance reviews.
- Secrets are blanked out of the record, as everywhere else.

It's **tamper-evident**, not tamper-proof: a program running as you with access to the vault key could rewrite the whole chain, and that's what the outside checkpoints catch.

### Undoable protects itself

An agent can't quietly switch Undoable off or cover its tracks. Changing `.claude/settings.json`, `.mcp.json`, the `.undoable/` folder or Undoable's records in the database always waits for you, whether through Claude Code's Edit tool, `sed`, `rm`, a redirect or a one-line Python or Node script. An agent also can't approve its own blocked actions (`undoable approve`, or pressing the dashboard's buttons).

### Disguised commands

Undoable sees through common disguises: `\rm`, `/bin/rm`, `env rm`, `sudo -u x rm`, `nohup`, `timeout`; `cd ~ && rm -rf .` (it follows `cd`, `pushd` and `Set-Location`); `git -C <other folder>`; code piped into a shell (`… | sh`, `base64 -d | bash`); `eval`; commands built from variables (`$x -rf ~`); shell commands inside `python -c`, `node -e`, `perl -e` and `awk`; and `ln -sf`, `tar -x -C`, `unzip -d` writing outside the project. Anything it can't read waits for you.

The full list lives in `test/coverage.test.ts` and `test/hardening.test.ts`: about 85 real-world agent actions, each with the decision Undoable must make.

## Money and messages

Some commands delete nothing, yet can't be undone either: a charge, refund or payout; an email, a Slack, WhatsApp or Telegram message, a GitHub pull request or comment; a package published for everyone. Undoable recognises them and a person says yes first:

- **Money:** Stripe, PayPal, Razorpay, Cashfree, PayU, Adyen, Square, Wise, Paystack, Flutterwave, and any API path for charges, refunds, payouts or transfers. Test mode (`sk_test_…`, `rzp_test_…`, sandboxes) moves no real money, so it doesn't ask. For the Stripe CLI, only a test key in the command counts as test mode: a live key in the environment would make the same command move real money.
- **Messages:** Slack, Discord, Telegram, WhatsApp, Twilio, SendGrid, Mailgun, Postmark, Resend, Brevo, Mailchimp, MSG91, Gmail, Outlook, Amazon SES and SNS, `mail`/`sendmail`, and `gh pr create`, `gh issue comment` and the like.
- **Publishing:** `npm publish`, `twine upload`, `cargo publish`, `gem push`, `gh release create`, editor extensions, NuGet.

Through curl, wget, httpie and PowerShell's `Invoke-RestMethod` alike. Reading (listing charges, viewing issues) stays allowed.

## Git backups that survive .git

Before a git command that changes history or throws work away (`reset --hard`, force-push, `clean`, `checkout -- .`, deleting a branch …), Undoable saves the state as git refs. Those live inside `.git`, so it also copies them, with every branch and tag, into a repository in its own folder (`~/.undoable`), outside the project. Only new commits are copied each time.

- If `.git` is later deleted, or its backups cleaned up (`git gc`), `undoable undo s3` still works: it rebuilds `.git` from that copy, with your branches, commits, uncommitted files and remotes.
- Deleting `.git` itself still asks a person, but `.git` is backed up first. If it's approved by mistake, `undoable undo` brings it back.
- Passwords in remote URLs are never kept, and your project's git hooks don't run for the copy.
- Repositories over the backup size limit (`UNDOABLE_MAX_BACKUP_MB`) skip the outside copy. Switch it off with `UNDOABLE_GIT_MIRROR=0`.

## Rules for deletes

Undoable always asks you before an agent deletes:
- **everything**: `.`, `*`, `..`, `~`, `C:\`, `/`, system folders
- **anything outside the project folder**, including your home folder written the Git Bash way (`/c/Users/you`)
- **paths built from variables** (`rm -rf "$p"`), because it can't tell where they point
- **files picked by another command** (`... | Remove-Item`)

Deletes inside the project are backed up first and can be undone.

Scripts are read before they run: if an agent runs `python cleanup.py`, `node clean.js`, `bash wipe.sh`, inline code (`python -c`, `node -e`) or an npm script, and the code deletes files or data (`shutil.rmtree`, `fs.rmSync`, `rm -rf`, `DROP TABLE` …), it waits for you.

Raw API calls are checked too: any `DELETE` request, or a GraphQL mutation that deletes something (like `volumeDelete`), waits for you, in both `curl` and `Invoke-RestMethod`.

## Networks that refuse database addresses

Some college and office networks refuse to look up addresses like `ep-….neon.tech` ("getaddrinfo ENOTFOUND"), although the database exists. When that happens, Undoable asks a public DNS **only to explain** it: whether your network refuses the address, or the address doesn't exist (a copy-paste slip, a deleted database).

If it's the network, one command lets Undoable's own connections ask public DNS (8.8.8.8, 1.1.1.1) whenever the network refuses:

```bash
undoable dns public      # remembered; nothing else on this computer changes
undoable dns system      # back to normal
```

Undoable never does this on its own: some networks block lookups on purpose, so it's your call. If the network also blocks the database connection itself, only another network (a phone hotspot, home Wi-Fi) helps.

## Known limits (for now)

- Undoable checks an action *before* the agent's own permission prompt. If you (or the agent's settings) then refuse it, the record still lists it as checked and backed up, though it never ran; undoing it changes nothing.
- Undo restores rows, columns, defaults, id counters and indexes. Foreign keys *pointing from* a dropped table are not rebuilt yet.
- Undo works without database admin rights (Supabase, Neon, AWS). Admins get a faster restore; normal users get a careful merge in foreign-key order. Rows elsewhere that point to rows added *after* the backup can block an undo.
- Backups are full table copies, so very large tables are slow to back up. Smarter backups come later.
- The hook works with Claude Code (Bash, PowerShell, Write, Edit), Codex CLI (shell commands and patches) and Gemini CLI (shell commands, write_file, replace). Cursor support is experimental. Other agents get the database tools through MCP, but their shell commands and file edits are not checked.
- Things outside the project (cloud resources, other databases, other machines) can't be backed up, so deletes there always wait for you; other changes there are logged but not undoable.
- Unfamiliar commands are judged by their words (`delete`, `destroy`, `reset` …) and by whether they point outside the project. A destructive command with an unusual name, working inside the project, still only gets a project backup.
- Reading commands catches mistakes and common disguises, not a determined attacker: code that builds its commands from data at run time can still get past. For strong protection, run the agent in a container or sandbox that can only see the project folder.
- PowerShell support covers the common commands (Remove-Item, Move-Item, Set-Content, …). Anything unfamiliar is backed up first in development and sent to you in production.
- Shell undo restores files, branches and remote branches. Files created *after* a backup are left in place.
- Database changes made through `psql` in the shell can't be backed up, so Claude Code asks you and suggests the `query_database` tool instead.
- Phone alerts work with a private chat with your bot (not group chats yet).
- Script checks look for delete code in the script itself. Code that builds a delete at run time, or loads it from another file, can still slip past.
- Started in your home folder (or `C:\`, `/`, a system folder), Claude Code isn't inside a project, so Undoable asks before deletes and moves there instead of backing them up.
- Admin locks on macOS/Linux make your group the folder's group with read access, so other members of that group (on macOS, usually "staff") can read it too.
- Locks (`undoable lock`) protect folders best. On Windows a single locked *file* can't be changed, but may still be deletable through its folder. On Linux, an empty locked folder can still be renamed.
- Your own rules for files and folders apply to commands that name them (also inside `python -c` …) and to Claude Code's file tools. A command that doesn't name a protected path, like a script that writes there, or `git checkout .`, isn't stopped by the rule (it's still backed up as usual), unless the folder is also locked with `undoable lock`. A command that only names a protected path to *read* it (`cat`, `grep`, `ls`) is fine; anything else that names it, such as `cp payments/x elsewhere`, counts as touching it.
- Named approvers (`by ravi`) approve on Telegram, so phone alerts must be running (`undoable alerts` or `undoable dashboard`). Team logins and a shared dashboard come with the team version.
- File backups live in the vault outside the project, encrypted. Git history backups are refs inside the project's `.git` (deleting `.git` always asks first). The encryption key sits on the same machine, so encryption protects copies of the vault (for example in a synced folder), not someone using your account.

